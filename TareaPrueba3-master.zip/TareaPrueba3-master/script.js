var score = 0; // Puntuación inicial
var scoreElement = document.getElementById('score');
var boardSize = 0;
var mineLocations = [];

// Función para iniciar el juego
function iniciarJuego() {
  alert("El juego ha comenzado");
  // Generar minas aleatoriamente
  generarMinasAleatorias();
}

// Función para reiniciar el juego
function reiniciarJuego() {
  alert("El juego ha sido reiniciado");
  // Reiniciar variables y tablero
  score = 0;
  scoreElement.textContent = score;
  document.querySelector('.menu').style.display = 'block';
  document.getElementById('board').style.display = 'none';
  boardSize = 0;
  mineLocations = [];
  var board = document.getElementById('board');
  while (board.firstChild) {
    board.removeChild(board.firstChild);
  }
}

// Obtener los elementos de los botones por su ID
var startButton = document.getElementById("startButton");
var restartButton = document.getElementById("restartButton");

// Agregar los controladores de eventos a los botones
startButton.addEventListener("click", iniciarJuego);
restartButton.addEventListener("click", reiniciarJuego);

function crearTablero(tamaño) {
  // Oculta el menú y muestra el tablero
  document.querySelector('.menu').style.display = 'none';
  document.getElementById('board').style.display = 'table';
  boardSize = tamaño;

  // Obtén una referencia al elemento de la tabla
  var board = document.getElementById('board');

  // Genera el tablero del tamaño especificado
  for (var i = 0; i < tamaño; i++) {
    var row = document.createElement('tr');
    for (var j = 0; j < tamaño; j++) {
      var cell = document.createElement('td');
      // Agrega un controlador de eventos a cada celda
      cell.addEventListener('click', function() {
        revelarCasilla(this);
        aumentarPuntuacion();
      });
      row.appendChild(cell);
    }
    board.appendChild(row);
  }
}

function aumentarPuntuacion() {
  score++;
  scoreElement.textContent = score;
}

function generarMinasAleatorias() {
  var totalCells = boardSize * boardSize;
  var totalMines = Math.floor(totalCells / 6); // Ajusta este valor para cambiar la cantidad de minas
  mineLocations = [];
  
  while (mineLocations.length < totalMines) {
    var randomIndex = Math.floor(Math.random() * totalCells);
    if (!mineLocations.includes(randomIndex)) {
      mineLocations.push(randomIndex);
    }
  }
}

function revelarCasilla(cell) {
  // Obtener las coordenadas de la celda actual
  var rowIndex = cell.parentNode.rowIndex;
  var cellIndex = cell.cellIndex;
  var cellId = rowIndex * boardSize + cellIndex;

  // Verificar si la celda contiene una mina
  if (mineLocations.includes(cellId)) {
    // Mostrar mensaje de juego terminado por encontrar una mina
    alert("¡Oops! Has encontrado una mina. Fin del juego.");
    reiniciarJuego();
    return;
  }

  // Contar las minas circundantes
  var count = 0;
  for (var i = rowIndex - 1; i <= rowIndex + 1; i++) {
    for (var j = cellIndex - 1; j <= cellIndex + 1; j++) {
      if (i >= 0 && i < boardSize && j >= 0 && j < boardSize) {
        var neighborCell = document.getElementById('board').rows[i].cells[j];
        var neighborId = i * boardSize + j;
        if (mineLocations.includes(neighborId)) {
          count++;
        }
      }
    }
  }

  // Mostrar la cantidad de minas circundantes en la casilla actual
  cell.textContent = count;
}
